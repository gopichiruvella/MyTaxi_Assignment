package com.mytaxi.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.ZonedDateTime;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.service.car.CarService;

/**
 * Test Controller for maintaining cars.
 */
@RunWith(PowerMockRunner.class)
public class CarControllerTest 
{
	private CarService service;
	private MockMvc mockMvc;
	private CarController controller;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		service = mock(CarService.class);		
		controller = PowerMockito.spy(new CarController(service));
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	//@Test
	public void testGetCar() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/cars")
    			.param("carId", "11"))    			
    			.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());		
	}
	
	//@Test
	public void testGetCar_Error() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/cars")
    			.param("carId", "-11"))    			
    			.andExpect(status().isBadRequest())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(400, response.getStatus());	
	}
	
	//@Test
	public void testCreateCar() throws Exception {
		CarDO carDO = new CarDO("AC89050", "Maruthi", EngineType.GAS);
		carDO.setCarId(15L);
		carDO.setDeleted(false);
		carDO.setDateCreated(ZonedDateTime.now());
		carDO.setRating("3 star");
		carDO.setSeatCount(3L);
		carDO.setConvertible("No");
		Mockito.when(service.create(Mockito.any(CarDO.class))).thenReturn(carDO);
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/v1/cars"))
				.andExpect(status().isCreated())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(201, response.getStatus());
	}
	
	//@Test
	public void testDeleteCar() throws Exception {
		Mockito.doNothing().when(service).delete(Mockito.anyLong());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/cars")
				.param("carId", "12"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	//@Test
	public void testDeleteCar_Error() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/cars")
				.param("carId", "-12"))
				.andExpect(status().isForbidden())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(403, response.getStatus());	
	}
	
	//@Test
	public void testUpdateCar() throws Exception {
		Mockito.doNothing().when(service).update(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put("/v1/cars")
				.param("carId", "15")
				.param("seatCount", "4L")
				.param("rating", "4 star"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@After
	public void tearDown() {
		mockMvc = null;
		service = null;
		controller = null;
	}
	
}