package com.mytaxi.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.service.driver.DriverService;

/**
 * Test controller for maintaining drivers.
 */
public class DriverControllerTest {

	private DriverService service;
	private MockMvc mockMvc;
	private DriverController controller;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		service = mock(DriverService.class);		
		controller = PowerMockito.spy(new DriverController(service));
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	//@Test
	public void testGetDriver() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/drivers")
    			.param("id", "1"))    			
    			.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());		
	}
	
	@Test
	public void testGetDriver_Error() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/drivers")
    			.param("id", "-1"))    			
    			.andExpect(status().isBadRequest())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(400, response.getStatus());
	}
	
	//@Test
	public void testCreateDriver() throws Exception {
		DriverDO driverDO = new DriverDO("mytaxiUser", "mytaxiPassword");
		driverDO.setId(20L);
		driverDO.setDeleted(false);
		driverDO.setOnlineStatus(OnlineStatus.ONLINE);
		GeoCoordinate geoCoordinate = new GeoCoordinate(67.5, 54.0);
		driverDO.setCoordinate(geoCoordinate);
		Mockito.when(service.create(Mockito.any(DriverDO.class))).thenReturn(driverDO);
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/v1/drivers"))
				.andExpect(status().isCreated())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(201, response.getStatus());
	}
	
	//@Test
	public void testDeleteDriver() throws Exception {
		Mockito.doNothing().when(service).delete(Mockito.anyLong());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/drivers")
				.param("id", "20"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	//@Test
	public void testDeleteDriver_Error() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/drivers")
				.param("id", "-20"))
				.andExpect(status().isForbidden())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(403, response.getStatus());
	}
	
	//@Test
	public void testUpdateLocation() throws Exception {
		Mockito.doNothing().when(service).updateLocation(Mockito.anyLong(), Mockito.anyFloat(), Mockito.anyFloat());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers")
				.param("id", "20")
				.param("longitude", "70.1")
				.param("latitude",  "59.1"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@Test
	public void testFindDrivers() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/drivers")
				.param("onlineStatus", "ONLINE"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@Test
	public void testFindDriversByDriverAndCarAttributes() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/drivers")
				.param("onlineStatus", "ONLINE")
				.param("username", "mytaxiUser")
				.param("licensePlate", "AC89050")
				.param("rating", "3 star")
				.param("seatCount", "3"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@Test
	public void testFindDriversByDriverAndCarAttributes_Error() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/drivers")
				.param("username", "unknown_mytaxiUser")
				.param("licensePlate", "unknown_AC89050"))
				.andExpect(status().isBadRequest())
    			.andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(400, response.getStatus());
	}
	
	@After
	public void tearDown() {
		mockMvc = null;
		service = null;
		controller = null;
	}
	
}