package com.mytaxi.domainobject;

import java.time.ZonedDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.mytaxi.domainvalue.EngineType;

/**
 *
 */
@Entity
@Table(
    name = "car",
    uniqueConstraints = @UniqueConstraint(name = "license_plate", columnNames = {"licensePlate"})
)
public class CarDO 
{

	@Id
    @GeneratedValue
    private Long carId;

    @Column(nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCreated = ZonedDateTime.now();

    @Column(nullable = false)
    @NotNull(message = "LicensePlate can not be null!")
    private String licensePlate;

    @Column
    private Long seatCount;

    @Column
    private String rating;

    @Column(nullable = false)
    private String convertible;
    
    @Column(nullable = false)
    private String manufacturer;
    
    @Column(nullable = false)
    private Boolean deleted = false;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EngineType engineType;
    
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "carDO", cascade = CascadeType.ALL)
    private DriverDO driverDO;
    
    /**
     * 
     */
    private CarDO() {}

    /**
     * @param licensePlate
     * @param manufacturer
     * @param engineType
     */
    public CarDO(String licensePlate, String manufacturer, EngineType engineType) {
    	this.licensePlate = licensePlate;
    	this.manufacturer = manufacturer;
    	this.engineType = engineType;
    	this.deleted = false;
    }
    
    /**
     * @return
     */
    public Long getCarId()
    {
        return carId;
    }

    /**
     * @param carId
     */
    public void setCarId(Long carId)
    {
        this.carId = carId;
    }

	/**
	 * @return
	 */
	public ZonedDateTime getDateCreated() {
		return dateCreated;
	}

	/**
	 * @param dateCreated
	 */
	public void setDateCreated(ZonedDateTime dateCreated) {
		this.dateCreated = dateCreated;
	}

	/**
	 * @return
	 */
	public String getLicensePlate() {
		return licensePlate;
	}

	/**
	 * @param licensePlate
	 */
	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	/**
	 * @return
	 */
	public Long getSeatCount() {
		return seatCount;
	}

	/**
	 * @param seatCount
	 */
	public void setSeatCount(Long seatCount) {
		this.seatCount = seatCount;
	}

	/**
	 * @return
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * @param rating
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}

	/**
	 * @return
	 */
	public String getConvertible() {
		return convertible;
	}

	/**
	 * @param convertible
	 */
	public void setConvertible(String convertible) {
		this.convertible = convertible;
	}

	/**
	 * @return
	 */
	public Boolean getDeleted() {
		return deleted;
	}

	/**
	 * @param deleted
	 */
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	/**
	 * @return
	 */
	public EngineType getEngineType() {
		return engineType;
	}

	/**
	 * @param engineType
	 */
	public void setEngineType(EngineType engineType) {
		this.engineType = engineType;
	}

	/**
	 * @return
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * @param manufacturer
	 */
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	/**
	 * @return
	 */
	public DriverDO getDriverDO() {
		return driverDO;
	}

	/**
	 * @param driverDO
	 */
	public void setDriverDO(DriverDO driverDO) {
		this.driverDO = driverDO;
	}

}