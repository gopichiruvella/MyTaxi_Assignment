package com.mytaxi.domainobject;

import java.time.ZonedDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;

/**
 *
 */
@Entity
@Table(
    name = "driver",
    uniqueConstraints = @UniqueConstraint(name = "uc_username", columnNames = {"username"})
)
public class DriverDO
{

    @Id
    @GeneratedValue
    private Long id;

    @Column(nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCreated = ZonedDateTime.now();

    @Column(nullable = false)
    @NotNull(message = "Username can not be null!")
    private String username;

    @Column(nullable = false)
    @NotNull(message = "Password can not be null!")
    private String password;

    @Column(nullable = false)
    private Boolean deleted = false;

    @Embedded
    private GeoCoordinate coordinate;

    @Column
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCoordinateUpdated = ZonedDateTime.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OnlineStatus onlineStatus;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "car_id")
    private CarDO carDO;

    /**
     * 
     */
    private DriverDO() {}


    /**
     * @param username
     * @param password
     */
    public DriverDO(String username, String password)
    {
        this.username = username;
        this.password = password;
        this.deleted = false;
        this.coordinate = null;
        this.dateCoordinateUpdated = null;
        this.dateCreated = ZonedDateTime.now();
        this.onlineStatus = OnlineStatus.OFFLINE;
    }


    /**
     * @return
     */
    public Long getId()
    {
        return id;
    }


    /**
     * @param id
     */
    public void setId(Long id)
    {
        this.id = id;
    }


    /**
     * @return
     */
    public ZonedDateTime getDateCreated() {
		return dateCreated;
	}


	/**
     * @return
     */
    public String getUsername()
    {
        return username;
    }


    /**
     * @return
     */
    public String getPassword()
    {
        return password;
    }


    /**
     * @return
     */
    public Boolean getDeleted()
    {
        return deleted;
    }


    /**
     * @param deleted
     */
    public void setDeleted(Boolean deleted)
    {
        this.deleted = deleted;
    }


    /**
     * @return
     */
    public OnlineStatus getOnlineStatus()
    {
        return onlineStatus;
    }


    /**
     * @param onlineStatus
     */
    public void setOnlineStatus(OnlineStatus onlineStatus)
    {
        this.onlineStatus = onlineStatus;
    }


    /**
     * @return
     */
    public GeoCoordinate getCoordinate()
    {
        return coordinate;
    }


    /**
     * @param coordinate
     */
    public void setCoordinate(GeoCoordinate coordinate)
    {
        this.coordinate = coordinate;
        this.dateCoordinateUpdated = ZonedDateTime.now();
    }


	/**
	 * @return
	 */
	public CarDO getCarDO() {
		return carDO;
	}


	/**
	 * @param carDO
	 */
	public void setCarDO(CarDO carDO) {
		this.carDO = carDO;
	}

}