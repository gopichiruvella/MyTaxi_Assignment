package com.mytaxi.domainvalue;

/**
 *
 */
public enum EngineType
{
    ELECTRIC, GAS
}
