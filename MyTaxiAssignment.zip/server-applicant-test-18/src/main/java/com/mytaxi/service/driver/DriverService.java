package com.mytaxi.service.driver;

import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import java.util.List;

/**
 *
 */
public interface DriverService
{

    /**
     * @param driverId
     * @return
     * @throws EntityNotFoundException
     */
    DriverDO find(Long driverId) throws EntityNotFoundException;

    /**
     * @param driverDO
     * @return
     * @throws ConstraintsViolationException
     */
    DriverDO create(DriverDO driverDO) throws ConstraintsViolationException;

    /**
     * @param driverId
     * @throws EntityNotFoundException
     */
    void delete(Long driverId) throws EntityNotFoundException;

    /**
     * @param driverId
     * @param longitude
     * @param latitude
     * @throws EntityNotFoundException
     */
    void updateLocation(long driverId, double longitude, double latitude) throws EntityNotFoundException;

    /**
     * @param onlineStatus
     * @return
     * @throws EntityNotFoundException
     */
    List<DriverDO> find(OnlineStatus onlineStatus) throws EntityNotFoundException;
    
    /**
     * @param username
     * @param onlineStatus
     * @return
     * @throws EntityNotFoundException
     */
    List<DriverDO> find(String username, OnlineStatus onlineStatus) throws EntityNotFoundException;
    
}
