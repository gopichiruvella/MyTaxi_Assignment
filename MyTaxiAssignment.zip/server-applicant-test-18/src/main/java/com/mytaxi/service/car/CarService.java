package com.mytaxi.service.car;

import java.util.List;

import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;

/**
 *
 */
public interface CarService
{

    /**
     * @param carId
     * @return
     * @throws EntityNotFoundException
     */
    CarDO find(Long carId) throws EntityNotFoundException;

    /**
     * @param carDO
     * @return
     * @throws ConstraintsViolationException
     */
    CarDO create(CarDO carDO) throws ConstraintsViolationException;

    /**
     * @param carId
     * @throws EntityNotFoundException
     */
    void delete(Long carId) throws EntityNotFoundException;

    /**
     * @param carId
     * @param seatCount
     * @param rating
     * @throws EntityNotFoundException
     */
    void update(Long carId, Long seatCount, String rating) throws EntityNotFoundException;
    
    /**
     * @param engineType
     * @return
     * @throws EntityNotFoundException
     */
    List<CarDO> find(EngineType engineType) throws EntityNotFoundException;
    
    /**
     * @param licensePlate
     * @param rating
     * @param seatCount
     * @return
     * @throws EntityNotFoundException
     */
    CarDO find(String licensePlate, String rating, Long seatCount) throws EntityNotFoundException;

}
