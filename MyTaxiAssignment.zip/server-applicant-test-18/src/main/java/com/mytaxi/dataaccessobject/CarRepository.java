package com.mytaxi.dataaccessobject;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.exception.EntityNotFoundException;

/**
 * Database Access Object for car table.
 * <p/>
 */
public interface CarRepository extends CrudRepository<CarDO, Long>
{

    /**
     * @param engineType
     * @return
     */
    List<CarDO> findByEngineType(EngineType engineType);
    
    /**
     * @param licensePlate
     * @param rating
     * @param seatCount
     * @return
     * @throws EntityNotFoundException
     */
    CarDO findByLicensePlateAndRatingAndSeatCount(String licensePlate, String rating, Long seatCount) throws EntityNotFoundException;
	
}
