package com.mytaxi.dataaccessobject;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.OnlineStatus;

/**
 * Database Access Object for driver table.
 * <p/>
 */
public interface DriverRepository extends CrudRepository<DriverDO, Long>
{

    /**
     * @param onlineStatus
     * @return
     */
    List<DriverDO> findByOnlineStatus(OnlineStatus onlineStatus);
    
    /**
     * @param username
     * @param onlineStatus
     * @param deleted
     * @return
     */
    List<DriverDO> findByUsernameAndOnlineStatusAndDeleted(String username, OnlineStatus onlineStatus, boolean deleted);
    
}
