package com.mytaxi.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mytaxi.controller.mapper.DriverMapper;
import com.mytaxi.datatransferobject.DriverDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.exception.CarAlreadyInUseException;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.exception.EntityNotFoundWithInputParametersException;
import com.mytaxi.service.car.CarService;
import com.mytaxi.service.driver.DriverService;

/**
 * All operations with a driver will be routed by this controller.
 * <p/>
 */
@RestController
@RequestMapping("v1/drivers")
public class DriverController
{

    private final DriverService driverService;
    private CarService carService;

    /**
     * @param driverService
     */
    @Autowired
    public DriverController(final DriverService driverService)
    {
        this.driverService = driverService;
    }
    
    /**
     * @param carService
     */
    @Autowired
    public void setCarService(CarService carService) {
    	this.carService = carService;
    }
    
    /**
     * @param driverId
     * @return
     * @throws EntityNotFoundException
     */
    @GetMapping("/{driverId}")
    public DriverDTO getDriver(@PathVariable long driverId) throws EntityNotFoundException
    {
        return DriverMapper.makeDriverDTO(driverService.find(driverId));
    }


    /**
     * @param driverDTO
     * @return
     * @throws ConstraintsViolationException
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DriverDTO createDriver(@Valid @RequestBody DriverDTO driverDTO) throws ConstraintsViolationException
    {
        DriverDO driverDO = DriverMapper.makeDriverDO(driverDTO);
        return DriverMapper.makeDriverDTO(driverService.create(driverDO));
    }


    /**
     * @param driverId
     * @throws EntityNotFoundException
     */
    @DeleteMapping("/{driverId}")
    public void deleteDriver(@PathVariable long driverId) throws EntityNotFoundException
    {
        driverService.delete(driverId);
    }


    /**
     * @param driverId
     * @param longitude
     * @param latitude
     * @throws EntityNotFoundException
     */
    @PutMapping("/{driverId}")
    public void updateLocation(
        @PathVariable long driverId, @RequestParam double longitude, @RequestParam double latitude)
        throws EntityNotFoundException
    {
        driverService.updateLocation(driverId, longitude, latitude);
    }
    
    /**
     * Method is to enable drivers to select a car they are driving with.
     * 
     * @param driverId
     * @param carId
     * @throws EntityNotFoundException
     * @throws ConstraintsViolationException
     * @throws CarAlreadyInUseException 
     */
    @PutMapping("/{driverId}, /{carId}")
    public void enableDriverToSelectACar(@PathVariable  long driverId, @PathVariable  long carId) throws EntityNotFoundException, ConstraintsViolationException, CarAlreadyInUseException {
    	CarDO carDO = null;
    	DriverDO driverDO = null;
    	
    	if (carId > 0 && driverId > 0) {
    		carDO = carService.find(carId);
    		driverDO = driverService.find(driverId);
    		if (carDO != null && driverDO != null && driverDO.getDeleted().equals(false)) {
    			if (!validateifCarIsAlreadyInUse(carId)) {
    				carDO.setDriverDO(driverDO);
    				driverDO.setCarDO(carDO);
    				carService.create(carDO);
    			} else {
    				throw new CarAlreadyInUseException("Car is already in use by one ONLINE driver: "+driverDO.getUsername());
    			}
    		} else {
    			if (carDO == null) {
        			throw new EntityNotFoundException("Car entity is not found");
        		} else {
        			throw new EntityNotFoundException("Driver entity is not found");
        		}
    		}
    	} else {
    		if (carId <= 0) {
    			throw new EntityNotFoundException("Entity is not found with given carId: "+carId);
    		} else if (driverId <= 0) {
    			throw new EntityNotFoundException("Entity is not found with given driverId: "+driverId);
    		}
    	}
    }
    
    
    /**
     * Method is to enable drivers to deselect a car.
     * 
     * @param driverId
     * @throws EntityNotFoundException
     * @throws ConstraintsViolationException 
     */
    @PutMapping
    public void enableDriverToDeselectACar(@RequestParam long driverId) throws EntityNotFoundException, ConstraintsViolationException {
    	CarDO carDO = null;
    	DriverDO driverDO = null;
    	
    	if (driverId > 0) {
    		driverDO = driverService.find(driverId);
    		if (driverDO != null && driverDO.getDeleted().equals(false)) {
	    		carDO = driverDO.getCarDO();
	    		if (carDO != null) {
					driverDO.setCarDO(null);
    				carDO.setDriverDO(null);
    				carService.create(carDO);
	    		}
    		} else {
    			throw new EntityNotFoundException("Driver entity is not found");
    		}
    	} else {
    		if (driverId <= 0) {
    			throw new EntityNotFoundException("Entity is not found with given driverId: "+driverId);
    		}
    	}
    }
    
    /**
     * Method is to validate if the car is already in use by other driver. 
     * 
     * @param carId
     * @throws CarAlreadyInUseException
     * @throws EntityNotFoundException
     * @throws ConstraintsViolationException
     */
    public boolean validateifCarIsAlreadyInUse(@PathVariable long carId) throws CarAlreadyInUseException, EntityNotFoundException, ConstraintsViolationException {
    	CarDO carDO = null;
    	boolean validateResult = false;
    	
    	if (carId > 0) {
    		carDO = carService.find(carId);
    		if (carDO != null) {
    			DriverDO driverDO = carDO.getDriverDO();
    			if (driverDO != null) {
    				if (driverDO.getOnlineStatus().equals(OnlineStatus.ONLINE)) {
    					throw new CarAlreadyInUseException("Car is already in use by one ONLINE driver: "+driverDO.getUsername());
    				} 
    				else {
    					driverDO.setCarDO(null);
        				carDO.setDriverDO(null);
        				carService.create(carDO);
    				}
    			} 
    		} else {
    			throw new EntityNotFoundException("Car entity is not found");
    		}
    	} else {
    		if (carId <= 0) {
    			throw new EntityNotFoundException("Entity is not found with given carId: "+carId);
    		}
    	}
    	
    	return validateResult;
    }
    
    
    /**
     * @param onlineStatus
     * @return
     * @throws EntityNotFoundException
     */
    @GetMapping
    public List<DriverDTO> findDrivers(@RequestParam OnlineStatus onlineStatus) throws EntityNotFoundException
    {
        return DriverMapper.makeDriverDTOList(driverService.find(onlineStatus));
    }
    
    
    /**
     * Method is to search drivers by their attributes (username, online_status) as well as car characteristics (license plate, rating, etc).
     * 
     * @param username
     * @param onlineStatus
     * @param licensePlate
     * @param rating
     * @param seatCount
     * @return list of drivers
     * @throws EntityNotFoundException 
     */
    @GetMapping("/{username}, /{onlineStatus}, /{licensePlate}, /{rating}, /{seatCount}")
    public List<DriverDTO> findDriversByDriverAndCarAttributes(@PathVariable String username, 
    									 @PathVariable OnlineStatus onlineStatus,
    									 @PathVariable String licensePlate,
    									 @PathVariable Long seatCount,
    									 @PathVariable String rating) throws EntityNotFoundWithInputParametersException, EntityNotFoundException {
    	List<DriverDO> listOfDrivers = new ArrayList<>();
    	/* select * from DriverDO as d inner join d.carDO as c where d.car_id = c.id and d.username = :username 
    	 * 															 				 and d.online_status = :onlineStatus 
    	 * 															 				 and c.license_plate = :licensePlate 
    	 * 														     				 and c.rating = :rating 
    	 * 															 				 and c.seat_count = :seatCount 
    	 * 															 				 and c.deleted = false */
    	List<DriverDO> driverDOs = driverService.find(username, onlineStatus);
    	CarDO carDO = carService.find(licensePlate, rating, seatCount);
    	
    	for (DriverDO driverDO : driverDOs) {
    		if (driverDO.getCarDO() != null && carDO != null && driverDO.getCarDO().getCarId().equals(carDO.getCarId())) {
    			listOfDrivers.add(driverDO);
    		} else {
    			throw new EntityNotFoundWithInputParametersException("Could not find driver entity with input parameters");
    		}
    	}
    	
    	if (listOfDrivers.size() > 0) {
    		return DriverMapper.makeDriverDTOList(listOfDrivers);
    	} else {
    		throw new EntityNotFoundWithInputParametersException("Could not find driver entity with input parameters");
    	}
    }
    
}
