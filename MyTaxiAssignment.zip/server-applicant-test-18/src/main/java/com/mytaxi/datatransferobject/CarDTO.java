package com.mytaxi.datatransferobject;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mytaxi.domainvalue.EngineType;

/**
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CarDTO
{
	@JsonIgnore
	private Long carId;

	@NotNull(message = "License Plate can not be null!")
	private String licensePlate;

	@NotNull(message = "Manufacturer can not be null!")
	private String manufacturer;

	@NotNull(message = "Engine Type can not be null!")
	private EngineType engineType;

	private CarDTO()
	{
	}


	/**
	 * @param carId
	 * @param licensePlate
	 * @param manufacturer
	 * @param engineType
	 */
	private CarDTO(Long carId, String licensePlate, String manufacturer, EngineType engineType)
	{
		this.carId = carId;
		this.licensePlate = licensePlate;
		this.manufacturer = manufacturer;
		this.engineType = engineType;
	}


	/**
	 * @return
	 */
	public static CarDTOBuilder newBuilder()
	{
		return new CarDTOBuilder();
	}


	/**
	 * @return
	 */
	@JsonProperty
	public Long getCarId()
	{
		return carId;
	}

	/**
	 * @return
	 */
	public String getLicensePlate()
	{
		return licensePlate;
	}

	/**
	 * @return
	 */
	public String getManufacturer()
	{
		return manufacturer;
	}

	/**
	 * @return
	 */
	public EngineType getEngineType()
	{
		return engineType;
	}

	public static class CarDTOBuilder
	{

		private Long carId;
		private String licensePlate;
		private String manufacturer;
		private EngineType engineType;

		/**
		 * @param carId
		 * @return
		 */
		public CarDTOBuilder setCarId(Long carId)
		{
			this.carId = carId;
			return this;
		}

		/**
		 * @param licensePlate
		 * @return
		 */
		public CarDTOBuilder setLicensePlate(String licensePlate)
		{
			this.licensePlate = licensePlate;
			return this;
		}

		/**
		 * @param manufacturer
		 * @return
		 */
		public CarDTOBuilder setManufacturer(String manufacturer) {
			this.manufacturer = manufacturer;
			return this;
		}

		/**
		 * @param engineType
		 * @return
		 */
		public CarDTOBuilder setEngineType(EngineType engineType) {
			this.engineType = engineType;
			return this;
		}

		/**
		 * @return
		 */
		public CarDTO createCarDTO()
		{
			return new CarDTO(carId, licensePlate, manufacturer, engineType);
		}

	}
}