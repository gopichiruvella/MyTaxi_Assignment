package com.mytaxi.datatransferobject;

import java.time.ZonedDateTime;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.domainvalue.GeoCoordinate;

/**
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DriverDTO
{
    @JsonIgnore
    private Long id;

    @NotNull(message = "Username can not be null!")
    private String username;

    @NotNull(message = "Password can not be null!")
    private String password;

    private GeoCoordinate coordinate;
    
    private ZonedDateTime dateCreated;

    private Long carId;
    
    private EngineType engineType;
    
    private String convertible;
    
    private String manufacturer;
    


    private DriverDTO()
    {
    }


    /**
     * @param id
     * @param username
     * @param password
     * @param coordinate
     * @param dateCreated
     * @param carId
     * @param engineType
     * @param convertible
     * @param manufacturer
     */
    private DriverDTO(Long id, String username, 
    						   String password, 
    						   GeoCoordinate coordinate, 
    						   ZonedDateTime dateCreated, 
    				  Long carId, 
    				  		   EngineType engineType, 
    				  		   String convertible, 
    				  		   String manufacturer)
    {
        this.id = id;
        this.username = username;
        this.password = password;
        this.coordinate = coordinate;
        this.dateCreated = dateCreated;
        this.carId = carId;
        this.engineType = engineType;
        this.convertible = convertible;
        this.manufacturer = manufacturer;
    }


    /**
     * @return
     */
    public static DriverDTOBuilder newBuilder()
    {
        return new DriverDTOBuilder();
    }


    /**
     * @return
     */
    @JsonProperty
    public Long getId()
    {
        return id;
    }


    /**
     * @return
     */
    public String getUsername()
    {
        return username;
    }


    /**
     * @return
     */
    public String getPassword()
    {
        return password;
    }


    /**
     * @return
     */
    public GeoCoordinate getCoordinate()
    {
        return coordinate;
    }
    
    
    /**
     * @return
     */
    public ZonedDateTime getDateCreated()
    {
        return dateCreated;
    }
    
    
    /**
     * @return
     */
    public Long getCarId()
    {
        return carId;
    }
    
    
    /**
     * @return
     */
    public EngineType getEngineType()
    {
        return engineType;
    }
    
    
    /**
     * @return
     */
    public String getConvertible()
    {
        return convertible;
    }
    
    
    /**
     * @return
     */
    public String getManufacturer()
    {
        return manufacturer;
    }
    

    public static class DriverDTOBuilder
    {
        private Long id;
        private String username;
        private String password;
        private GeoCoordinate coordinate;
        private ZonedDateTime dateCreated;
        private Long carId;
        private EngineType engineType;
        private String convertible;
        private String manufacturer;


        /**
         * @param id
         * @return
         */
        public DriverDTOBuilder setId(Long id)
        {
            this.id = id;
            return this;
        }


        /**
         * @param username
         * @return
         */
        public DriverDTOBuilder setUsername(String username)
        {
            this.username = username;
            return this;
        }


        /**
         * @param password
         * @return
         */
        public DriverDTOBuilder setPassword(String password)
        {
            this.password = password;
            return this;
        }


        /**
         * @param coordinate
         * @return
         */
        public DriverDTOBuilder setCoordinate(GeoCoordinate coordinate)
        {
            this.coordinate = coordinate;
            return this;
        }
        
        
        /**
         * @param dateCreated
         * @return
         */
        public DriverDTOBuilder setDateCreated(ZonedDateTime dateCreated)
        {
            this.dateCreated = dateCreated;
            return this;
        }
        
        
        /**
         * @param carId
         * @return
         */
        public DriverDTOBuilder setCarId(Long carId) 
        {
        	this.carId = carId;
        	return this;
        }
        
        
        /**
         * @param engineType
         * @return
         */
        public DriverDTOBuilder setEngineType(EngineType engineType) 
        {
        	this.engineType = engineType;
        	return this;
        }
        
        
        /**
         * @param convertible
         * @return
         */
        public DriverDTOBuilder setConvertible(String convertible) 
        {
        	this.convertible = convertible;
        	return this;
        }
        
        
        /**
         * @param carId
         * @return
         */
        public DriverDTOBuilder setManufacturer(String manufacturer) 
        {
        	this.manufacturer = manufacturer;
        	return this;
        }


        /**
         * @return
         */
        public DriverDTO createDriverDTO()
        {
            return new DriverDTO(id, username, password, coordinate, dateCreated, carId, engineType, convertible, manufacturer);
        }

    }
}